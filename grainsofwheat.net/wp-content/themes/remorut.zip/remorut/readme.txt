Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/remorut/
Buy theme: http://smthemes.com/buy/remorut/
Support Forums: http://smthemes.com/support/forum/remorut-free-wordpress-theme/